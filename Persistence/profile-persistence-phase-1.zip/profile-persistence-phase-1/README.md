# Profile Persistence — Phase 1

This package replaces browser `localStorage` profile persistence with authenticated Azure SQL persistence.

## Endpoints

- `GET /api/profile/me`
- `PUT /api/profile/me`

The server obtains the owner from `request.auth.userId`. The frontend never supplies ownership.

## Files

Copy each file from this package to the matching project path:

- `backend/src/database/migrations/005_profile_details.sql`
- `backend/src/repositories/profileRepository.js`
- `backend/src/schemas/profileSchemas.js`
- `backend/src/services/Service/profileService.js`
- `backend/src/controllers/profileController.js`
- `backend/src/routes/profileRoutes.js`
- `backend/test/api/profileApi.test.js`
- `frontend/src/services/Profile/profileApiService.js`
- `frontend/src/context/ProfileDataContext.api.jsx`

For the two frontend files, use these destinations:

- Rename `profileApiService.js` to `profileService.js`, replacing the existing file.
- Rename `ProfileDataContext.api.jsx` to `ProfileDataContext.jsx`, replacing the existing file.

## Required app.js changes

Add this import:

```js
import profileRoutes from "./routes/profileRoutes.js";
```

Add this route before `notFoundHandler`:

```js
app.use("/api/profile", profileRoutes);
```

Remove the old comment saying Profile routes are disabled.

## package.json changes

Add the Profile backend files to `check` if desired. Add this script:

```json
"test:profile-api": "node --experimental-test-module-mocks --test --test-concurrency=1 test/api/profileApi.test.js"
```

## Run order

```powershell
cd backend
npm run check
npm run db:migrate
npm run test:profile-api
npm test
npm run dev
```

In another PowerShell terminal:

```powershell
cd frontend
npm run dev
```

## Picture policy

This phase stores picture metadata only. It rejects `blob:` and `data:` image URLs because those are browser-local or embed image bytes. Azure Blob Storage should be added in a separate media phase.

