import { Router } from "express";
import { requireAuthentication } from "../middleware/authenticationMiddleware.js";
import {
  getMyProfile,
  updateMyProfile,
} from "../controllers/profileController.js";

const router = Router();

router.use(requireAuthentication);

router.get("/me", getMyProfile);
router.put("/me", updateMyProfile);

export default router;

