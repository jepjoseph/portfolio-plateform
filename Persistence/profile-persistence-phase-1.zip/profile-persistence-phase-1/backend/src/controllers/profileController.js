import {
  getAuthenticatedProfile,
  updateAuthenticatedProfile,
} from "../services/Service/profileService.js";
import { parseProfileUpdate } from "../schemas/profileSchemas.js";

function setPrivateHeaders(response) {
  response.set({
    "Cache-Control": "no-store, no-cache, must-revalidate, private",
    Pragma: "no-cache",
    Expires: "0",
  });
}

export async function getMyProfile(request, response, next) {
  try {
    const profile = await getAuthenticatedProfile({
      userId: request.auth.userId,
    });

    setPrivateHeaders(response);

    return response.status(200).json({
      status: "success",
      message: "Profile retrieved successfully.",
      data: { profile },
    });
  } catch (error) {
    return next(error);
  }
}

export async function updateMyProfile(request, response, next) {
  try {
    const profileInput = parseProfileUpdate(request.body);

    const profile = await updateAuthenticatedProfile({
      userId: request.auth.userId,
      profile: profileInput,
    });

    setPrivateHeaders(response);

    return response.status(200).json({
      status: "success",
      message: "Profile saved successfully.",
      data: { profile },
    });
  } catch (error) {
    return next(error);
  }
}

