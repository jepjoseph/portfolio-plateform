import {
  findProfileByUserId,
  replaceProfileByUserId,
} from "../../repositories/profileRepository.js";

function createProfileError({ message, code, status, publicMessage }) {
  const error = new Error(message);
  error.name = "ProfileServiceError";
  error.code = code;
  error.status = status;
  error.publicMessage = publicMessage;
  return error;
}

function assertUserId(userId) {
  if (typeof userId !== "string" || !userId.trim()) {
    throw createProfileError({
      message: "An authenticated user ID is required.",
      code: "PROFILE_AUTHENTICATION_REQUIRED",
      status: 401,
      publicMessage: "You must sign in to access your Profile.",
    });
  }

  return userId.trim();
}

export async function getAuthenticatedProfile({ userId }) {
  const profile = await findProfileByUserId(assertUserId(userId));

  if (!profile) {
    throw createProfileError({
      message: "The authenticated user does not have a Profile row.",
      code: "PROFILE_NOT_FOUND",
      status: 404,
      publicMessage: "Your Profile could not be found.",
    });
  }

  return profile;
}

export async function updateAuthenticatedProfile({ userId, profile }) {
  const updatedProfile = await replaceProfileByUserId(
    assertUserId(userId),
    profile,
  );

  if (!updatedProfile) {
    throw createProfileError({
      message: "The authenticated user Profile could not be updated.",
      code: "PROFILE_NOT_FOUND",
      status: 404,
      publicMessage: "Your Profile could not be found.",
    });
  }

  return updatedProfile;
}

