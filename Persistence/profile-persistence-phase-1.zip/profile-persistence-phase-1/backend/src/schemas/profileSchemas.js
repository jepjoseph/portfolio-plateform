import { z } from "zod";

const itemIdSchema = z.string().trim().min(1).max(200);
const statusSchema = z.enum(["active", "archived"]);

const timestampSchema = z
  .string()
  .datetime({ offset: true })
  .optional();

const commonItemFields = {
  id: itemIdSchema,
  description: z.string().trim().max(500).default(""),
  order: z.number().int().min(0),
  status: statusSchema,
  createdAt: timestampSchema,
  updatedAt: timestampSchema,
};

const professionalTitleSchema = z
  .object({
    ...commonItemFields,
    name: z.string().trim().min(1).max(200),
  })
  .strict();

const CONTACT_TYPES = {
  emails: ["personal", "work", "school", "business", "other"],
  phones: ["personal", "mobile", "home", "work", "school", "other"],
  websites: [
    "portfolio",
    "personal",
    "business",
    "company",
    "school",
    "blog",
    "other",
  ],
  locations: ["home", "office", "work", "school", "business", "other"],
  socialLinks: [
    "linkedin",
    "github",
    "youtube",
    "facebook",
    "instagram",
    "x",
    "other",
  ],
};

const CONTACT_LIMITS = {
  emails: 320,
  phones: 50,
  websites: 2048,
  locations: 500,
  socialLinks: 2048,
};

function createContactSchema(category) {
  return z
    .object({
      ...commonItemFields,
      type: z.enum(CONTACT_TYPES[category]),
      value: z.string().trim().min(1).max(CONTACT_LIMITS[category]),
    })
    .strict();
}

const externalUrlSchema = z
  .string()
  .trim()
  .max(2048)
  .refine(
    (value) =>
      !value ||
      (/^https:\/\//i.test(value) && !/^https:\/\/(?:localhost|127\.0\.0\.1)/i.test(value)),
    "Saved picture URLs must use a public HTTPS address.",
  )
  .refine(
    (value) => !/^(?:data|blob):/i.test(value),
    "Browser-local and embedded image URLs cannot be saved.",
  );

const profilePictureSchema = z
  .object({
    ...commonItemFields,
    type: z.string().trim().max(100).default(""),
    imageUrl: externalUrlSchema.default(""),
    blobName: z.string().trim().max(255).default(""),
    fileName: z.string().trim().max(255).default(""),
    fileType: z.string().trim().max(100).default(""),
    fileSize: z.number().int().min(0).max(20 * 1024 * 1024).default(0),
    useDefaultAvatar: z.boolean().default(false),
    width: z.number().int().positive().nullable().default(null),
    height: z.number().int().positive().nullable().default(null),
  })
  .strict()
  .superRefine((picture, context) => {
    if (picture.useDefaultAvatar && (picture.imageUrl || picture.blobName)) {
      context.addIssue({
        code: "custom",
        path: ["useDefaultAvatar"],
        message: "A default avatar cannot also reference an uploaded image.",
      });
    }
  });

const preferenceSchema = z
  .object({
    primaryProfessionalTitleId: z.string().trim().max(200).default(""),
    primaryEmailId: z.string().trim().max(200).default(""),
    primaryPhoneId: z.string().trim().max(200).default(""),
    primaryWebsiteId: z.string().trim().max(200).default(""),
    primaryLocationId: z.string().trim().max(200).default(""),
    primarySocialLinkId: z.string().trim().max(200).default(""),
    primaryProfilePictureId: z.string().trim().max(200).default(""),
  })
  .strict();

const visibilitySchema = z
  .object({
    isPublic: z.boolean().default(false),
  })
  .strict();

export const profileUpdateSchema = z
  .object({
    firstName: z.string().trim().max(100).default(""),
    middleName: z.string().trim().max(100).default(""),
    lastName: z.string().trim().max(100).default(""),
    professionalTitles: z.array(professionalTitleSchema).max(20).default([]),
    emails: z.array(createContactSchema("emails")).max(20).default([]),
    phones: z.array(createContactSchema("phones")).max(20).default([]),
    websites: z.array(createContactSchema("websites")).max(20).default([]),
    locations: z.array(createContactSchema("locations")).max(20).default([]),
    socialLinks: z.array(createContactSchema("socialLinks")).max(30).default([]),
    profilePictures: z.array(profilePictureSchema).max(20).default([]),
    preferences: preferenceSchema.default({}),
    visibility: visibilitySchema.default({}),
    status: statusSchema.default("active"),
  })
  .strict()
  .superRefine((profile, context) => {
    const mappings = [
      ["primaryProfessionalTitleId", "professionalTitles"],
      ["primaryEmailId", "emails"],
      ["primaryPhoneId", "phones"],
      ["primaryWebsiteId", "websites"],
      ["primaryLocationId", "locations"],
      ["primarySocialLinkId", "socialLinks"],
      ["primaryProfilePictureId", "profilePictures"],
    ];

    for (const [preferenceName, collectionName] of mappings) {
      const requestedId = profile.preferences[preferenceName];

      if (!requestedId) continue;

      const isActiveItem = profile[collectionName].some(
        (item) => item.id === requestedId && item.status === "active",
      );

      if (!isActiveItem) {
        context.addIssue({
          code: "custom",
          path: ["preferences", preferenceName],
          message: "The primary item must reference an active item in its collection.",
        });
      }
    }
  });

function createValidationError(zodError) {
  const error = new Error("Profile validation failed.");
  error.name = "ProfileValidationError";
  error.code = "PROFILE_VALIDATION_FAILED";
  error.status = 400;
  error.publicMessage = "Review the Profile information and try again.";
  error.errors = zodError.issues.map((issue) => ({
    field: issue.path.join("."),
    code: issue.code,
    message: issue.message,
  }));
  error.fieldErrors = {};

  for (const issue of error.errors) {
    const field = issue.field || "_form";
    error.fieldErrors[field] ||= [];
    error.fieldErrors[field].push(issue.message);
  }

  return error;
}

export function parseProfileUpdate(input) {
  const result = profileUpdateSchema.safeParse(input);

  if (!result.success) {
    throw createValidationError(result.error);
  }

  return result.data;
}

