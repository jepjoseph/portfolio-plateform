import assert from "node:assert/strict";
import { beforeEach, describe, it, mock } from "node:test";
import express from "express";
import supertest from "supertest";

process.env.NODE_ENV = "test";
process.env.SESSION_COOKIE_NAME = "portfolio_refresh_token";
process.env.SESSION_COOKIE_PATH = "/api";
process.env.SESSION_COOKIE_SAME_SITE = "lax";
delete process.env.SESSION_COOKIE_DOMAIN;

const USER_ID = "11111111-1111-4111-8111-111111111111";
const SESSION_ID = "22222222-2222-4222-8222-222222222222";
const TOKEN = "profile-test-refresh-token-12345678901234567890";

let state;

function createProfile() {
  return {
    modelVersion: 1,
    id: USER_ID,
    userId: USER_ID,
    firstName: "Jean",
    middleName: "Pierre",
    lastName: "Joseph",
    professionalTitles: [],
    emails: [],
    phones: [],
    websites: [],
    locations: [],
    socialLinks: [],
    profilePictures: [],
    preferences: {
      primaryProfessionalTitleId: "",
      primaryEmailId: "",
      primaryPhoneId: "",
      primaryWebsiteId: "",
      primaryLocationId: "",
      primarySocialLinkId: "",
      primaryProfilePictureId: "",
    },
    visibility: { isPublic: false },
    status: "active",
    createdAt: "2026-09-23T00:00:00.000Z",
    updatedAt: "2026-09-23T00:00:00.000Z",
  };
}

function resetState() {
  state = {
    getInput: null,
    updateInput: null,
    getError: null,
    updateError: null,
    profile: createProfile(),
  };
}

resetState();

mock.module("../../src/services/Service/sessionService.js", {
  exports: {
    async getAuthenticatedSession() {
      return {
        user: {
          id: USER_ID,
          email: "jean@example.com",
          emailVerifiedAt: "2026-09-23T00:00:00.000Z",
          accountStatus: "active",
        },
        roles: ["user"],
        session: {
          id: SESSION_ID,
          deviceName: "Test Browser",
          createdAt: "2026-09-23T00:00:00.000Z",
          lastUsedAt: "2026-09-23T00:00:00.000Z",
          expiresAt: "2026-10-23T00:00:00.000Z",
          isCurrent: true,
        },
      };
    },
  },
});

mock.module("../../src/services/Service/profileService.js", {
  exports: {
    async getAuthenticatedProfile(input) {
      state.getInput = input;
      if (state.getError) throw state.getError;
      return state.profile;
    },
    async updateAuthenticatedProfile(input) {
      state.updateInput = input;
      if (state.updateError) throw state.updateError;
      state.profile = { ...state.profile, ...input.profile };
      return state.profile;
    },
  },
});

const { default: profileRoutes } = await import("../../src/routes/profileRoutes.js");
const { globalErrorHandler, notFoundHandler } = await import("../../src/middleware/errorMiddleware.js");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use("/api/profile", profileRoutes);
app.use(notFoundHandler);
app.use(globalErrorHandler);
const api = supertest(app);

function cookie() {
  return `portfolio_refresh_token=${encodeURIComponent(TOKEN)}`;
}

function updateBody() {
  const { modelVersion, id, userId, createdAt, updatedAt, ...body } = createProfile();
  return body;
}

describe("profile API", () => {
  beforeEach(resetState);

  it("returns the authenticated user's Profile", async () => {
    const response = await api
      .get("/api/profile/me")
      .set("Cookie", cookie())
      .expect(200);

    assert.equal(response.body.status, "success");
    assert.equal(response.body.data.profile.userId, USER_ID);
    assert.deepEqual(state.getInput, { userId: USER_ID });
    assert.match(response.headers["cache-control"], /no-store/);
  });

  it("does not accept ownership from the request body", async () => {
    const response = await api
      .put("/api/profile/me")
      .set("Cookie", cookie())
      .send({ ...updateBody(), userId: "99999999-9999-4999-8999-999999999999" })
      .expect(400);

    assert.equal(response.body.code, "PROFILE_VALIDATION_FAILED");
    assert.equal(state.updateInput, null);
  });

  it("updates the Profile using the authenticated user ID", async () => {
    const body = { ...updateBody(), firstName: "  Jean  " };

    const response = await api
      .put("/api/profile/me")
      .set("Cookie", cookie())
      .send(body)
      .expect(200);

    assert.equal(state.updateInput.userId, USER_ID);
    assert.equal(state.updateInput.profile.firstName, "Jean");
    assert.equal(response.body.data.profile.firstName, "Jean");
  });

  it("requires an authenticated cookie", async () => {
    await api.get("/api/profile/me").expect(401);
    assert.equal(state.getInput, null);
  });

  it("rejects browser-local picture URLs", async () => {
    const body = updateBody();
    body.profilePictures = [
      {
        id: "picture-test",
        type: "profile",
        imageUrl: "blob:http://localhost/picture",
        blobName: "",
        fileName: "picture.png",
        fileType: "image/png",
        fileSize: 100,
        useDefaultAvatar: false,
        width: 100,
        height: 100,
        description: "",
        order: 0,
        status: "active",
        createdAt: "2026-09-23T00:00:00.000Z",
        updatedAt: "2026-09-23T00:00:00.000Z",
      },
    ];

    const response = await api
      .put("/api/profile/me")
      .set("Cookie", cookie())
      .send(body)
      .expect(400);

    assert.equal(response.body.code, "PROFILE_VALIDATION_FAILED");
    assert.equal(state.updateInput, null);
  });
});

